interface UserInterface { 
    email: string; 
    password: string;  
    role : "user" | "admin";  
}
export { UserInterface };